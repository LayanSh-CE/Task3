﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Task33.Models;
public class Department
{
    public int DepartmentId { get; set; }  // dp_id
    public string DepartmentName { get; set; } = null!;  // dp_name
    public string Location { get; set; } = null!;

    public ICollection<Doctor> Doctors { get; set; } = new List<Doctor>();

}
