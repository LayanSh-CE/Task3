﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Task33.Models;
public class Test
{ 
   public int TestId { get; set; }
public int PatientId { get; set; }
public int DoctorId { get; set; }
public int VisitId { get; set; }
public string TestType { get; set; } = null!;

public Patient Patient { get; set; } = null!;
    public Doctor Doctor { get; set; } = null!;
    public Visit Visit { get; set; } = null!;

}
