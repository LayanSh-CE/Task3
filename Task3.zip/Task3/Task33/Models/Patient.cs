﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Task33.Models;
public class Patient
{
    public int PatientId { get; set; }
    public string PatientName { get; set; } = null!;  // pt_name
    public string Gender { get; set; } = null!;
    public DateTime DateOfBirth { get; set; }  // dob

    public ICollection<Visit> Visits { get; set; } = new List<Visit>();
    public ICollection<Test> Tests { get; set; } = new List<Test>();

}
