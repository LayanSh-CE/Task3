﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace Task33.Models;
public class Doctor
{

    public int DoctorId { get; set; }
    public int DepartmentId { get; set; }  // dp_id
    public string FirstName { get; set; } = null!;  // fname
    public string LastName { get; set; } = null!;  // lname

    [JsonIgnore]
    public Department? Department { get; set; }  // Make nullable
    [JsonIgnore]
    public ICollection<Visit> Visits { get; set; } = new List<Visit>();
    [JsonIgnore]
    public ICollection<Test> Tests { get; set; } = new List<Test>();

}
