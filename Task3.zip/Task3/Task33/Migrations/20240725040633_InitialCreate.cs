﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace Task33.Migrations
{
    /// <inheritdoc />
    public partial class InitialCreate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "department",
                columns: table => new
                {
                    dp_id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    dp_name = table.Column<string>(type: "nvarchar(32)", maxLength: 32, nullable: false),
                    location = table.Column<string>(type: "nvarchar(32)", maxLength: 32, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_department", x => x.dp_id);
                });

            migrationBuilder.CreateTable(
                name: "patients",
                columns: table => new
                {
                    pt_id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    pt_name = table.Column<string>(type: "nvarchar(32)", maxLength: 32, nullable: false),
                    gender = table.Column<string>(type: "nvarchar(32)", maxLength: 32, nullable: false),
                    dob = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_patients", x => x.pt_id);
                });

            migrationBuilder.CreateTable(
                name: "doctors",
                columns: table => new
                {
                    doctor_id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    dp_id = table.Column<int>(type: "int", nullable: false),
                    fname = table.Column<string>(type: "nvarchar(32)", maxLength: 32, nullable: false),
                    lname = table.Column<string>(type: "nvarchar(32)", maxLength: 32, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_doctors", x => x.doctor_id);
                    table.ForeignKey(
                        name: "FK_doctors_department_dp_id",
                        column: x => x.dp_id,
                        principalTable: "department",
                        principalColumn: "dp_id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "visits",
                columns: table => new
                {
                    visit_id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    pt_id = table.Column<int>(type: "int", nullable: false),
                    doctor_id = table.Column<int>(type: "int", nullable: false),
                    visit_date = table.Column<DateTime>(type: "datetime2", nullable: false),
                    purpose = table.Column<string>(type: "nvarchar(32)", maxLength: 32, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_visits", x => x.visit_id);
                    table.ForeignKey(
                        name: "FK_visits_doctors_doctor_id",
                        column: x => x.doctor_id,
                        principalTable: "doctors",
                        principalColumn: "doctor_id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_visits_patients_pt_id",
                        column: x => x.pt_id,
                        principalTable: "patients",
                        principalColumn: "pt_id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "tests",
                columns: table => new
                {
                    test_id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    pt_id = table.Column<int>(type: "int", nullable: false),
                    doctor_id = table.Column<int>(type: "int", nullable: false),
                    visit_id = table.Column<int>(type: "int", nullable: false),
                    test_type = table.Column<string>(type: "nvarchar(32)", maxLength: 32, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tests", x => x.test_id);
                    table.ForeignKey(
                        name: "FK_tests_doctors_doctor_id",
                        column: x => x.doctor_id,
                        principalTable: "doctors",
                        principalColumn: "doctor_id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_tests_patients_pt_id",
                        column: x => x.pt_id,
                        principalTable: "patients",
                        principalColumn: "pt_id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_tests_visits_visit_id",
                        column: x => x.visit_id,
                        principalTable: "visits",
                        principalColumn: "visit_id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.InsertData(
                table: "department",
                columns: new[] { "dp_id", "dp_name", "location" },
                values: new object[,]
                {
                    { 1, "Cardiology", "Building A" },
                    { 2, "Neurology", "Building B" }
                });

            migrationBuilder.InsertData(
                table: "doctors",
                columns: new[] { "doctor_id", "dp_id", "fname", "lname" },
                values: new object[,]
                {
                    { 1, 1, "Dr. Smith", "Omar" },
                    { 2, 2, "Dr. Johnson", "Omar" }
                });

            migrationBuilder.CreateIndex(
                name: "IX_doctors_dp_id",
                table: "doctors",
                column: "dp_id");

            migrationBuilder.CreateIndex(
                name: "IX_tests_doctor_id",
                table: "tests",
                column: "doctor_id");

            migrationBuilder.CreateIndex(
                name: "IX_tests_pt_id",
                table: "tests",
                column: "pt_id");

            migrationBuilder.CreateIndex(
                name: "IX_tests_visit_id",
                table: "tests",
                column: "visit_id");

            migrationBuilder.CreateIndex(
                name: "IX_visits_doctor_id",
                table: "visits",
                column: "doctor_id");

            migrationBuilder.CreateIndex(
                name: "IX_visits_pt_id",
                table: "visits",
                column: "pt_id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "tests");

            migrationBuilder.DropTable(
                name: "visits");

            migrationBuilder.DropTable(
                name: "doctors");

            migrationBuilder.DropTable(
                name: "patients");

            migrationBuilder.DropTable(
                name: "department");
        }
    }
}
