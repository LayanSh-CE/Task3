﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Task33.Models;
using Task33.Data;
using Microsoft.EntityFrameworkCore;

namespace Task33.Repositories
{
    public interface IDoctorRepository
    {
        Task<List<Doctor>> GetAllDoctorsAsync();
        Task<Doctor> GetDoctorByIdAsync(int id);

        Task UpdateDoctorAsync(int id, Doctor updatedDoctor);

        Task DeleteDoctorAsync(int id); 

        Task AddDoctorAsync(Doctor newDoctor);

    }

    public class DoctorRepository : IDoctorRepository
    {
        private readonly HealthCareContext _healthCareContext;

        public DoctorRepository(HealthCareContext healthCareContext)
        {
            _healthCareContext = healthCareContext;
        }

        public async Task<List<Doctor>> GetAllDoctorsAsync()
        {
            return await _healthCareContext.Doctors.ToListAsync();
        }

        public async Task<Doctor> GetDoctorByIdAsync(int id)
        {
            // Find the doctor by ID
            var doctor = await _healthCareContext.Doctors
                                                 .FindAsync(id);

            // Check if doctor exists and return it
            if (doctor == null)
            {
                throw new KeyNotFoundException($"Doctor with ID {id} not found.");
            }

            return doctor;
        }

        public async Task UpdateDoctorAsync(int id, Doctor updatedDoctor)
        {
            var doctor = await _healthCareContext.Doctors
                                                 .SingleOrDefaultAsync(d => d.DoctorId == id);

            if (doctor == null)
            {
                throw new KeyNotFoundException($"Doctor with ID {id} not found.");
            }

            // Log the current state of the doctor
            Console.WriteLine($"Updating Doctor ID {id}: {doctor.FirstName} {doctor.LastName}");

            // Update only the specified fields
            doctor.DepartmentId = updatedDoctor.DepartmentId;
            doctor.FirstName = updatedDoctor.FirstName;
            doctor.LastName = updatedDoctor.LastName;

            // Log the updated state
            Console.WriteLine($"Updated Doctor ID {id}: {doctor.FirstName} {doctor.LastName}");

            // Save changes
            await _healthCareContext.SaveChangesAsync();
        }

        public async Task DeleteDoctorAsync(int id)
        {
            var doctor = await _healthCareContext.Doctors
                                                 .SingleOrDefaultAsync(d => d.DoctorId == id);

            if (doctor == null)
            {
                throw new KeyNotFoundException($"Doctor with ID {id} not found.");
            }

            _healthCareContext.Doctors.Remove(doctor);
            await _healthCareContext.SaveChangesAsync();
        }

        public async Task AddDoctorAsync(Doctor doctor)
        {
            if (doctor == null)
            {
                throw new ArgumentNullException(nameof(doctor), "Doctor cannot be null.");
            }

            _healthCareContext.Doctors.Add(doctor);
            await _healthCareContext.SaveChangesAsync();
        }



    }
}
