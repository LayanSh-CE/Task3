﻿using Task33.Models;
using Microsoft.EntityFrameworkCore;

namespace Task33.Data;

public class HealthCareContext : DbContext
    {
        public HealthCareContext() { }
    public HealthCareContext(DbContextOptions<HealthCareContext> options)
   : base(options) { }
    public DbSet<Doctor> Doctors { get; set; } = null!;
        public DbSet<Patient> Patients { get; set; } = null!;
        public DbSet<Department> Departments { get; set; } = null!;
        public DbSet<Visit> Visits { get; set; } = null!;
        public DbSet<Test> Tests { get; set; } = null!;

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=HealthCareDB;Integrated Security=True;");
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {

            
            modelBuilder.Entity<Department>(entity =>
            {
                entity.ToTable("department");
                entity.HasKey(e => e.DepartmentId);
                entity.Property(e => e.DepartmentId).HasColumnName("dp_id").ValueGeneratedOnAdd();
                entity.Property(e => e.DepartmentName).HasColumnName("dp_name").HasMaxLength(32).IsRequired();
                entity.Property(e => e.Location).HasColumnName("location").HasMaxLength(32).IsRequired();
            });

            modelBuilder.Entity<Doctor>(entity =>
            {
                entity.ToTable("doctors");
                entity.HasKey(e => e.DoctorId);
                entity.Property(e => e.DoctorId).HasColumnName("doctor_id").ValueGeneratedOnAdd();
                entity.Property(e => e.FirstName).HasColumnName("fname").HasMaxLength(32).IsRequired();
                entity.Property(e => e.LastName).HasColumnName("lname").HasMaxLength(32).IsRequired();
                entity.Property(e => e.DepartmentId).HasColumnName("dp_id");

                entity.HasOne(e => e.Department)
                      .WithMany(d => d.Doctors)
                      .HasForeignKey(e => e.DepartmentId);
            });

            modelBuilder.Entity<Patient>(entity =>
            {
                entity.ToTable("patients");
                entity.HasKey(e => e.PatientId);
                entity.Property(e => e.PatientId).HasColumnName("pt_id").ValueGeneratedOnAdd();
                entity.Property(e => e.PatientName).HasColumnName("pt_name").HasMaxLength(32).IsRequired();
                entity.Property(e => e.Gender).HasColumnName("gender").HasMaxLength(32).IsRequired();
                entity.Property(e => e.DateOfBirth).HasColumnName("dob").IsRequired();
            });

            modelBuilder.Entity<Visit>(entity =>
            {
                entity.ToTable("visits");
                entity.HasKey(e => e.VisitId);
                entity.Property(e => e.VisitId).HasColumnName("visit_id").ValueGeneratedOnAdd();
                entity.Property(e => e.VisitDate).HasColumnName("visit_date").IsRequired();
                entity.Property(e => e.Purpose).HasColumnName("purpose").HasMaxLength(32).IsRequired();
                entity.Property(e => e.PatientId).HasColumnName("pt_id");
                entity.Property(e => e.DoctorId).HasColumnName("doctor_id");

                entity.HasOne(e => e.Patient)
                      .WithMany(p => p.Visits)
                      .HasForeignKey(e => e.PatientId);

                entity.HasOne(e => e.Doctor)
                      .WithMany(d => d.Visits)
                      .HasForeignKey(e => e.DoctorId);
            });

            modelBuilder.Entity<Test>(entity =>
            {
                entity.ToTable("tests");
                entity.HasKey(e => e.TestId);
                entity.Property(e => e.TestId).HasColumnName("test_id").ValueGeneratedOnAdd();
                entity.Property(e => e.TestType).HasColumnName("test_type").HasMaxLength(32).IsRequired();
                entity.Property(e => e.PatientId).HasColumnName("pt_id");
                entity.Property(e => e.DoctorId).HasColumnName("doctor_id");
                entity.Property(e => e.VisitId).HasColumnName("visit_id");

                entity.HasOne(e => e.Patient)
                      .WithMany(p => p.Tests)
                      .HasForeignKey(e => e.PatientId)
                      .OnDelete(DeleteBehavior.Restrict);


                entity.HasOne(e => e.Doctor)
                      .WithMany(d => d.Tests)
                      .HasForeignKey(e => e.DoctorId)
                      .OnDelete(DeleteBehavior.Restrict);


                entity.HasOne(e => e.Visit)
                      .WithMany(v => v.Tests)
                      .HasForeignKey(e => e.VisitId)
                      .OnDelete(DeleteBehavior.Restrict);

            });

            base.OnModelCreating(modelBuilder);

        // Seed Department data
        modelBuilder.Entity<Department>().HasData(
            new Department { DepartmentId = 1, DepartmentName = "Cardiology", Location = "Building A" },
            new Department { DepartmentId = 2, DepartmentName = "Neurology", Location = "Building B" }
        );


        modelBuilder.Entity<Doctor>().HasData(
 new Doctor { DoctorId = 1, FirstName = "Dr. Smith", LastName = "Omar", DepartmentId = 1 },
 new Doctor { DoctorId = 2, FirstName = "Dr. Johnson", LastName = "Omar", DepartmentId = 2 }
);
        modelBuilder.Entity<Doctor>()
    .Property(d => d.DoctorId)
    .ValueGeneratedOnAdd();

        base.OnModelCreating(modelBuilder);


        }
    }


