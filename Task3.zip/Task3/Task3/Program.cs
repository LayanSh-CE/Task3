using Task33.Models;
using Microsoft.EntityFrameworkCore;
using Task33.Data;
using Task33.Repositories;
using Microsoft.OpenApi.Models;
var builder = WebApplication.CreateBuilder(args);
var connetionString = builder.Configuration.GetConnectionString("Task3ConnectionString");

builder.Services.AddDbContext<HealthCareContext>(options =>
{
options.UseSqlServer(connetionString);
});

 builder.Services.AddScoped<IDoctorRepository,DoctorRepository>();
builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo { Title = "API WSVAP (WebSmartView)", Version = "v1" });
    c.ResolveConflictingActions(apiDescriptions => apiDescriptions.First()); //This line
});


var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI(c =>
    {
        c.SwaggerEndpoint("./v1/swagger.json", "My API V1"); //originally "./swagger/v1/swagger.json"
    });
}

app.UseHttpsRedirection();
app.UseAuthorization();
app.MapControllers();
app.Run();


